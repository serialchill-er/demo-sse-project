
A simple Spring Boot application that demonstrates the usage of 
the [sse-eventbus](https://github.com/ralscha/sse-eventbus) library.

#### Start the application

```
clone -> run ->open localhost:80/index.html -> open console and analyse
```
Thanks to @ralscha
